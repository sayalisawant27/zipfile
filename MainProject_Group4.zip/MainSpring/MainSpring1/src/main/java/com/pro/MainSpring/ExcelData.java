package com.pro.MainSpring;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelData {
	
	public static String inputData; 

	public static String readExcelData(String sheetName) throws Exception { 
		
		//Excelfile path 

		String workingDir=System.getProperty("user.dir"); 

		String excelFilePath=workingDir+File.separator+"ExcelInput.xlsx"; 

		//Excel file 

		FileInputStream excelFile=new FileInputStream(excelFilePath); 

		//XSSFWorkbook 

		XSSFWorkbook workbook = new XSSFWorkbook(excelFile); 

		//XSSFSheet 

		XSSFSheet sheet=workbook.getSheet(sheetName); 

		//XSSFRow 

		XSSFRow row; 

		//XSSFCell 

		XSSFCell cell; 

		//Reading the data from the excel 

		row=sheet.getRow(0);
		
		cell=row.getCell(0); 

		inputData=String.valueOf(cell); 
       
	

		workbook.close(); 

		//Returning the String array storing the excel data 

		return inputData; 

}
	public static void writeExcel(String[] error,String sheetname) { 

		//XSSFWorkbook 

		XSSFWorkbook workbook = new XSSFWorkbook(); 

		//XSSFSheet 

		XSSFSheet sheet = workbook.createSheet(sheetname); 

		//Writing the data 

		Row row1 = sheet.createRow(0); 

		Cell cell = row1.createCell(0); 

		cell.setCellValue("Alerts for download attatchments"); 

		for(int i=0;i<error.length;i++) { 

		Row row=sheet.createRow(i); 

		Cell cell1=row.createCell(0); 

		cell1.setCellValue(error[i]); 

		} 

		try { 

		FileOutputStream file = new FileOutputStream("ExcelOutput.xlsx"); 

		workbook.write(file); 

		workbook.close(); 

		}catch(Exception e) { 

		e.printStackTrace(); 

		} 
	}
}