package com.pro.MainSpring;


import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SprintLogin {
	
public static WebDriverWait wait;
public static WebDriver driver;

public static void login(WebDriver driver) throws Exception {
    //wait until website opens
	wait=new WebDriverWait(driver, 180);
    wait.until(ExpectedConditions.titleContains("mainspring"));
}

 public static void navigateSprint(WebDriver driver) throws Exception {
	
	 //locate hamburger icon
	 wait=new WebDriverWait(driver, 30);
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div[1]/header/nav/div/div/div[3]/div[1]/span")));
     
     //move to hamburgur icon
     Actions action=new Actions(driver);
     Thread.sleep(2000);
     HighlightElement.highlightElement(driver, driver.findElement(By.xpath("/html/body/div[1]/div[1]/header/nav/div/div/div[3]/div[1]/span")));
     action.moveToElement(driver.findElement(By.xpath("/html/body/div[1]/div[1]/header/nav/div/div/div[3]/div[1]/span"))).build().perform();
    
     
     //locate "View my project/programs" 
     wait=new WebDriverWait(driver, 40);
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[8]/div[3]/ul/li[5]/ul/li[2]/a")));
     driver.findElement(By.xpath("/html/body/div[8]/div[3]/ul/li[5]/ul/li[2]/a")).click();
     Thread.sleep(3000);
     
     //click on project
     wait=new WebDriverWait(driver, 50);
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/div[1]")));
     driver.findElement(By.xpath("//body[1]/div[1]/div[2]/div[2]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[2]/table[1]/tbody[1]/tr[1]/td[3]/div[1]")).click();
     Thread.sleep(3000);
     
    //move to "Plan" tab
     wait=new WebDriverWait(driver, 70);
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("LOCK_Plan")));
     action.moveToElement(driver.findElement(By.id("LOCK_Plan"))).build().perform();
     
     //click on "Sprints"
    
     wait=new WebDriverWait(driver, 20);
     wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("LOCK_Sprints")));
     driver.findElement(By.id("LOCK_Sprints")).click();
    }
}