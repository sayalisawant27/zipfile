package com.pro.MainSpring;

 import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions; public class DriverSetup {     public static WebDriver driver;
    public static WebDriver setUpDriver() {
        String chromeDriverPath = "\\driver\\chromedriver_win32\\chromedriver.exe";
        String path=System.getProperty("user.dir");
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-notifications");
        System.setProperty("webdriver.chrome.driver", path+chromeDriverPath);
        driver =new ChromeDriver(options);
        driver.get("https://pratesting.cognizant.com/");
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        return driver;
    } }