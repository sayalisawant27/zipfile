package com.pro.MainSpring;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.pro.MainSpring.TestNG;

import com.relevantcodes.extentreports.LogStatus;

public class AddSprint{
	public static WebDriver driver;
	static CaptureScreenshot cst=new CaptureScreenshot();
	public static String filePath=null;  
		
	public static void addSprint(WebDriver driver) throws InterruptedException {
	  WebDriverWait wait;
	   
		//addbutton
		Thread.sleep(3000);
	//To highlight the add button
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div/div/a[1]/span/span/span[1]"))); 

	    //To click on the add button driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div/div/a[1]/span/span/span[1]")).click();

	     //switch frame
	     driver.switchTo().frame("contentframe");
	    wait=new WebDriverWait(driver, 30);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[1]/td[5]/input[1]")));
	    
	//To highlight the name field  HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[1]/td[5]/input[1]")));   
	 
	//To enter value “Trial” in Name field   driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[1]/td[5]/input[1]")).sendKeys("Trial");
	    driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); 

	//To highlight the description field  
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td[2]/textarea"))); 
	   
	 //To enter value “Trial description” in Description field    driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td[2]/textarea")).sendKeys("Trial description");
	//To highlight the Sprint Type field
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td[5]/select")));     

	    //To select a Sprint type by using value
	     Select dtp=new Select(driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[2]/td[5]/select")));
	    dtp.selectByValue("221484");

	//To highlight the Release Field    
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[4]/td[2]/select"))); 

	    //To select a Release by using value
	    Select rel=new Select(driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[4]/td[2]/select")));
	    rel.selectByValue("64838");
	    
	//To highlight the responsibility field
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[5]/td[2]/select"))); 
	   
	 //To select a Responsibility by value
	    Select res=new Select(driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[5]/td[2]/select")));
	    res.selectByValue("77816");
	    
	//To highlight the Team field
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[10]/td[5]/select")));

	    //To select a team using Index
	    Select team=new Select(driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[10]/td[5]/select")));
	    team.selectByIndex(2);
	    
	//To highlight start date
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("//*[@id=\'STARTDATE\']")));

	    //To insert startdate in proper date format
	    driver.findElement(By.xpath("//*[@id=\'STARTDATE\']")).click();
	    driver.findElement(By.xpath("//*[@id=\'STARTDATE\']")).sendKeys("21-Feb-2021");

	//To highlight enddate field
	HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\'ENDDATE\']")));

	    //To insert enddate in proper date format
	    driver.findElement(By.xpath("//*[@id=\'ENDDATE\']")).click();
	    driver.findElement(By.xpath("//*[@id=\'ENDDATE\']")).sendKeys("3-Mar-2021");
	   
	//To highlight No. of teams field
	HighlightElement.highlightElement(driver, driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[5]/td[5]/input")));


	    //To insert the value for no. of teams as “4”    driver.findElement(By.xpath("/html/body/form/table[2]/tbody/tr/td/div/table/tbody/tr/td/table/tbody/tr[5]/td[5]/input")).sendKeys("4");
	    
	    filePath=System.getProperty("user.dir")+"/Screenshots/addSprint.png";
		cst.captureScreenshot(driver, filePath);
		TestNG.test.log(LogStatus.INFO, "Screenshot:"+TestNG.test.addScreenCapture(filePath));
	    
	    driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); 

	//To highlight on save button field  
	HighlightElement.highlightElement(driver, driver.findElement(By.xpath("/html/body/form/table[3]/tbody/tr/td/table/tbody/tr/td[2]/input")));

	 //To click on the save button     driver.findElement(By.xpath("/html/body/form/table[3]/tbody/tr/td/table/tbody/tr/td[2]/input")).click();
	    
	    Alert alert=driver.switchTo().alert();
	    alert.accept();

	    //switch to iframe
	    driver.switchTo().parentFrame();
	    driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS); 
	   
	    wait=new WebDriverWait(driver, 30);
	    wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div[1]/div[3]/div[1]/div/div/ul/li[3]/a")));

	//To highlight return button field
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div[1]/div/div/ul/li[3]/a")));

	    //To click on return button and go back to the main page
	    driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div[1]/div/div/ul/li[3]/a")).click();
	    
	  }

	}

