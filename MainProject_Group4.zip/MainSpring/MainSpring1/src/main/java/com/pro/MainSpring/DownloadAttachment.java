package com.pro.MainSpring;

import java.util.concurrent.TimeUnit;
import com.pro.MainSpring.TestNG;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.LogStatus;

public class DownloadAttachment {
	public static WebDriver driver;
	static String[] alertMsg=new String[2];
	static CaptureScreenshot cst=new CaptureScreenshot();
	public static String filePath=null; 
	
	 public static void download(WebDriver driver) throws Exception {
	    	
		    //wait 
		    driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		    
		    //check a checkbox of sprint
	    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div[2]/div[1]/div[1]/div[2]/table[5]/tbody/tr/td[1]/div/div")).click();
	    	
	    	//click on download
	    	HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_BatchDownload_Tooltip-btnIconEl\"]")));
	    	driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_BatchDownload_Tooltip-btnIconEl\"]")).click();
	    	
	    	//handling alert box
	    	WebDriverWait wait = new WebDriverWait(driver, 2);
	    	wait.until(ExpectedConditions.alertIsPresent());
	    	
	    	//switch to alert box
			Alert alert=driver.switchTo().alert();
			String err=alert.getText();
			//print alert message on console
			System.out.println(err);
			//store msg in array
			alertMsg[0]=err;
			Thread.sleep(3000);
			//Accept alert
			alert.accept();
			
	    }
	 public static  void SearchAndDwnld(WebDriver driver) throws Exception
		{
		    driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			//click on search box
			WebElement ele=driver.findElement(By.xpath("//*[@id=\"searchTextBox-inputEl\"]"));
			
			//Read sprint name from excel file "InputData.xlsx"
			
			String data=ExcelData.readExcelData("SprintName"); 
	        ele.sendKeys(data);
	        
	        //click on search button
	        HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"searchButton\"]")));
	        driver.findElement(By.xpath("//*[@id=\"searchButton\"]")).click();
	        driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
	       
	        //click on download
	        HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_BatchDownload_Tooltip-btnIconEl\"]")));
			driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_BatchDownload_Tooltip-btnIconEl\"]")).click();
			
			//handling alert box
			WebDriverWait wait = new WebDriverWait(driver, 2);
	    	wait.until(ExpectedConditions.alertIsPresent());
	    	
	    	//switch to alert box
			Alert alert=driver.switchTo().alert();
			String err1=alert.getText();
			//print alert message on console
			System.out.println(err1);
			//store msg in array
			alertMsg[1]=err1;
			Thread.sleep(3000);
	    	//Accept alert
			alert.accept();
			
			filePath=System.getProperty("user.dir")+"/Screenshots/downloadSprint.png";
	    	cst.captureScreenshot(driver, filePath);
	    	TestNG.test.log(LogStatus.INFO, "Screenshot:"+TestNG.test.addScreenCapture(filePath));
	    	
			driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
			//select sprint 
			HighlightElement.highlightElement(driver, driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div[2]/div[1]/div[1]/div[2]/table/tbody/tr/td[1]/div/div")));
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[1]/div/div/div[1]/div[2]/div[1]/div[1]/div[2]/table/tbody/tr/td[1]/div/div")).click();
			
			//click on download
			HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_BatchDownload_Tooltip-btnWrap\"]")));
			driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_BatchDownload_Tooltip-btnWrap\"]")).click();
			
			//write alert messages in "OutputData.xlsx" file
			ExcelData.writeExcel(alertMsg, "AlertMsg");
			
			//display all sprints
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div/div/div[4]/div/div/div/input")).click();
			driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div/div/div[4]/div/div/div/input")).clear();
			HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"searchButton\"]")));
			driver.findElement(By.xpath("//*[@id=\"searchButton\"]")).click();
		}
}

