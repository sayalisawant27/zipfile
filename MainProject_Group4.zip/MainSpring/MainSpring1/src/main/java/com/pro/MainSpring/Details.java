package com.pro.MainSpring;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.pro.MainSpring.TestNG;
import com.relevantcodes.extentreports.LogStatus;

 

//name of the class
   public class Details {
      static WebDriver driver;
      static WebDriverWait wait=null;
      static CaptureScreenshot cst=new CaptureScreenshot();
  	public static String filePath=null; 
  	
     //functionality for display items per page
    public static void displayItem(WebDriver driver) {
    	driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS); 
        Actions action=new Actions(driver);
    	WebElement pagenum=driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[10]/div/div/div/div[1]/input"));
    	action.moveToElement(pagenum).click(pagenum).perform();
    	action.sendKeys(Keys.DOWN).build().perform();
    	action.sendKeys(Keys.ENTER).build().perform();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
    }
    
   //functionality for display page number
    public static void pageNumber(WebDriver driver) {
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[4]/div/div/div[1]/input")).click();
    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[4]/div/div/div[1]/input")).clear();
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[4]/div/div/div[1]/input")).sendKeys("2");
       //now press "Enter" key to procced
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[4]/div/div/div[1]/input")).sendKeys(Keys.ENTER);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }
    
    //functionality of "Next" button
    public static void buttonNext(WebDriver driver) {
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/a[3]/span/span/span[1]")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
    }
    
      //functionality of "Last" button
       public static void buttonLast(WebDriver driver) {
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/a[4]/span/span/span[1]")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
        
        filePath=System.getProperty("user.dir")+"/Screenshots/sprintDetails.png";
       	cst.captureScreenshot(driver, filePath);
       	TestNG.test.log(LogStatus.INFO, "Screenshot:"+TestNG.test.addScreenCapture(filePath));
    }
   
    //functionality of "Refresh" button
    public static void buttonRefresh(WebDriver driver) {
        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/a[5]/span/span/span[1]")).click();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
    }

    
}
 