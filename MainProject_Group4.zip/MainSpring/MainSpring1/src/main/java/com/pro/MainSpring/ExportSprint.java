package com.pro.MainSpring;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.LogStatus;
import com.pro.MainSpring.TestNG;

public class ExportSprint {
	public static WebDriver driver;
	static CaptureScreenshot cst=new CaptureScreenshot();
	public static String filePath=null; 
	
	 public static void exportSprint(WebDriver driver) throws Exception {
		   
		    driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		    //click on Export sprint button
	    	driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div/div/a[2]/span")).click();
             
	    	// Switch to new window opened
	    	String mainWindow=driver.getWindowHandle();
	    	for(String winHandle : driver.getWindowHandles()){
	        driver.switchTo().window(winHandle);
	    	}
	
	    	//select radio button "XLSM"
	    	driver.findElement(By.xpath("/html/body/form/div[2]/div/div[1]/div[1]/div[2]/input")).click();
	    	
	    	//select the export type "Skeletal Export"
	    	driver.findElement(By.xpath("//*[@id=\"Skeletal\"]")).click();
	    	driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    	
	    	//click on Reset button
	    	HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"QTP_KEY_BUTTON_Reset\"]")));
	    	driver.findElement(By.xpath("//*[@id=\"QTP_KEY_BUTTON_Reset\"]")).click();
	    	
	    	
	    	//select radio button "XLS"
	    	driver.findElement(By.xpath("//*[@id=\"ExportFormat\"]")).click();
	    	
	    	//select the export type
	    	driver.findElement(By.xpath("//*[@id=\"ZipOutput\"]")).click();
	    	driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
	    	
	    	 
	        filePath=System.getProperty("user.dir")+"/Screenshots/exportSprint.png";
	    	cst.captureScreenshot(driver, filePath);
	    	TestNG.test.log(LogStatus.INFO, "Screenshot:"+TestNG.test.addScreenCapture(filePath));
	    	
	    	//click on Ok button
	    	HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"QTP_KEY_BUTTON_Ok\"]")));
	    	driver.findElement(By.xpath("//*[@id=\"QTP_KEY_BUTTON_Ok\"]")).click();
	    	driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	    	
	    	//click on Return button
	    	HighlightElement.highlightElement(driver, driver.findElement(By.xpath("//*[@id=\"QTP_KEY_BUTTON_Close\"]")));
	    	driver.findElement(By.xpath("//*[@id=\"QTP_KEY_BUTTON_Close\"]")).click();
	    	
	    	//return to main window
	    	driver.switchTo().window(mainWindow);
	    	
	    }
	 
	 
}
