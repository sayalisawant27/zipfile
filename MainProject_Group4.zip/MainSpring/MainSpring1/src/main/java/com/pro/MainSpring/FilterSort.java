package com.pro.MainSpring;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.pro.MainSpring.TestNG;
import com.relevantcodes.extentreports.LogStatus;

public class FilterSort {
	public static WebDriver driver;
	public static WebDriverWait wait;
	public static Select select;
	public static Scanner sc=new Scanner(System.in);
	static CaptureScreenshot cst=new CaptureScreenshot();
	public static String filePath=null; 

	//To create a new filter
	public static void createFilter(WebDriver driver) {
		
		//Click on Advance Filter icon and click on Create in the option
	    driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		HighlightElement.highlightElement(driver,driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_Advanced_Filter\"]")));
		driver.findElement(By.xpath("//*[@id=\"KEY_LABEL_Advanced_Filter\"]")).click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		HighlightElement.highlightElement(driver,driver.findElement(By.xpath("//*[@id=\"advanceFilterCreateButton-KEY_LABEL_Advanced_Filter\"]")));
	driver.findElement(By.xpath("//*[@id=\"advanceFilterCreateButton-KEY_LABEL_Advanced_Filter\"]")).click();
		
		//To get the handle of the current window
		String mainWindow=driver.getWindowHandle();
		
		//To get the List of handles of all the child windows
		Set<String> s1=driver.getWindowHandles();
		Iterator<String> i1=s1.iterator();
		while(i1.hasNext()) {
		String childWindow=i1.next();
		if(!mainWindow.equalsIgnoreCase(childWindow)) {
		
		//Switch to the child window
		driver.switchTo().window(childWindow);
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Enter the filter name
		HighlightElement.highlightElement(driver,driver.findElement(By.name("filtername")));
		driver.findElement(By.name("filtername")).clear();
		driver.findElement(By.name("filtername")).sendKeys("Filter abc");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Enter the description of the filter
		HighlightElement.highlightElement(driver,driver.findElement(By.name("filterdesc")));
		driver.findElement(By.name("filterdesc")).sendKeys("Creating a new filter");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Click on Global Filter checkbox
		HighlightElement.highlightElement(driver,driver.findElement(By.name("isGlobalFilter")));
		driver.findElement(By.name("isGlobalFilter")).click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Select the option from dropdown box
			HighlightElement.highlightElement(driver,driver.findElement(By.name("LeftBrace1")));
		select=new Select(driver.findElement(By.name("LeftBrace1")));
		driver.findElement(By.name("LeftBrace1")).click();
		select.selectByVisibleText("{");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Select the field name
		HighlightElement.highlightElement(driver,driver.findElement(By.name("FieldName1")));
		select=new Select(driver.findElement(By.name("FieldName1")));
		driver.findElement(By.name("FieldName1")).click();
		select.selectByVisibleText("Start Date");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Select the operator
		HighlightElement.highlightElement(driver,driver.findElement(By.name("Operator1")));
		select=new Select(driver.findElement(By.name("Operator1")));
		driver.findElement(By.name("Operator1")).click();
		select.selectByVisibleText("=");
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		//Choose the date
		HighlightElement.highlightElement(driver,driver.findElement(By.id("date_img_1_2")));
		driver.findElement(By.id("date_img_1_2")).click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		select=new Select(driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/div/select[1]")));
		driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/div[1]/div/select[1]")).click();
		select.selectByVisibleText("Feb");
		
		HighlightElement.highlightElement(driver,driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[2]/td[4]/a")));
	driver.findElement(By.xpath("//*[@id=\"ui-datepicker-div\"]/table/tbody/tr[2]/td[4]/a")).click();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		
		//Select the option from the dropdown 
		HighlightElement.highlightElement(driver,driver.findElement(By.name("RightBrace1")));
	select=new Select(driver.findElement(By.name("RightBrace1")));
		driver.findElement(By.name("RightBrace1")).click();
		select.selectByVisibleText("}");
		
		filePath=System.getProperty("user.dir")+"/Screenshots/CreateFilter.png";
		cst.captureScreenshot(driver, filePath);
		TestNG.test.log(LogStatus.INFO, "Screenshot:"+TestNG.test.addScreenCapture(filePath));
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/form/table[3]/tbody/tr/td[1]/table/tbody/tr[1]/td[1]/input")));
	driver.findElement(By.xpath("/html/body/form/table[3]/tbody/tr/td[1]/table/tbody/tr[1]/td[1]/input")).click();
		
		
		}
		}
		//switch to main window
		driver.switchTo().window(mainWindow);
		}

		//To clear all the filters applied
		 public static void clearFilter(WebDriver driver) {
		
	    //Click on the Clear All Filters icon
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		HighlightElement.highlightElement(driver,driver.findElement(By.id("clearFilterButton")));
		driver.findElement(By.id("clearFilterButton")).click();
		}
		 
		//To sort the sprint details
		 public static void sorting(WebDriver driver) {
			 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			
		  //Click on the Multiple Sort icon
		HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div/div/a[8]")));
	       driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[2]/div[1]/div/div/div/a[8]")).click();
				
			driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			//Enter the column name and select
			
			WebElement s=driver.findElement(By.xpath("//*[@id=\"primaryColumn-inputEl\"]"));
		     Actions action=new Actions(driver);
			 action.moveToElement(s).click(s).perform();
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("//*[@id=\"primaryColumn-inputEl\"]")));
			 s.clear();
			 s.sendKeys("Name");
			s.sendKeys(Keys.TAB);
			 driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
			
			 //Enter the sorting order and select
			 WebElement PAsc=driver.findElement(By.xpath("//*[@id=\"primaryOrderBy-inputEl\"]"));
	 action.moveToElement(PAsc).click(PAsc).perform();	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("//*[@id=\"primaryOrderBy-inputEl\"]")));

			  PAsc.clear();
			 PAsc.sendKeys("Descending");
			 PAsc.sendKeys(Keys.ENTER);
			 
			 filePath=System.getProperty("user.dir")+"/Screenshots/sorting.png";
		    	cst.captureScreenshot(driver, filePath);
		    	TestNG.test.log(LogStatus.INFO, "Screenshot:"+TestNG.test.addScreenCapture(filePath));
			
			 //Click on Go
	HighlightElement.highlightElement(driver,driver.findElement(By.xpath("/html/body/div[14]/div[2]/div/div[2]/div/div/a[1]/span/span/span[2]")));
			action.moveToElement(driver.findElement(By.xpath("/html/body/div[14]/div[2]/div/div[2]/div/div/a[1]/span/span/span[2]"))).click(driver.findElement(By.xpath("/html/body/div[14]/div[2]/div/div[2]/div/div/a[1]/span/span/span[2]"))).perform();


		 }

	}

