package com.pro.MainSpring;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class TestNG {
	public static WebDriver driver;
	static String extentReportFile=System.getProperty("user.dir")+"/ExtentReport/extentReportFile.html";
	public static ExtentReports report = new ExtentReports(extentReportFile);
	public static ExtentTest test;
	static CaptureScreenshot cst=new CaptureScreenshot();
	public static String filePath=null; 
	@BeforeTest
	public WebDriver getDriver() throws Exception {
	test = report.startTest("Mainspring-Sprint");
	test.log(LogStatus.INFO, "Opening the Browser");
	driver=DriverSetup.setUpDriver();
	test.log(LogStatus.PASS, "Browser Opened");
	test.log(LogStatus.INFO, "Opening the site: https://pratesting.cognizant.com/");
	test.log(LogStatus.PASS, "Website Opened Successfully");
    
	filePath=System.getProperty("user.dir")+"/Screenshots/SignIn.png";
	cst.captureScreenshot(driver, filePath);
	test.log(LogStatus.INFO, "Screenshot:"+test.addScreenCapture(filePath));

	return driver;
	}
	
	@Test
	public static void openSprint() throws Exception {
		SprintLogin.login(driver);
		test.log(LogStatus.INFO, "Navigating to sprints module");
	    SprintLogin.navigateSprint(driver);
	    test.log(LogStatus.PASS, "Navigated to Sprint module successfully");
	    
	    filePath=System.getProperty("user.dir")+"/Screenshots/homepageScreenshot.png";
		cst.captureScreenshot(driver, filePath);
		test.log(LogStatus.INFO, "Screenshot:"+test.addScreenCapture(filePath));
	}
	
	@Test(dependsOnMethods="openSprint")
	public static void add() throws Exception {
		test.log(LogStatus.INFO, "Creating a new Sprint");
		AddSprint.addSprint(driver);
		test.log(LogStatus.PASS, "Sprint added successfully");
		
		
	}
	
	@Test(dependsOnMethods="add")
	public static void export() throws Exception {
		test.log(LogStatus.INFO, "Exporting Sprint");
		ExportSprint.exportSprint(driver);
		test.log(LogStatus.PASS, "Sprint exported successfully");
	}
	
	@Test(dependsOnMethods="export")
	public static void searchDownloadSprint() throws Exception {
		test.log(LogStatus.INFO, "Searching and Downloading Sprint");
		DownloadAttachment.download(driver);
		DownloadAttachment.SearchAndDwnld(driver);
		test.log(LogStatus.PASS, "Searched Sprint downloaded successfully");
		
	}
	
	@Test(dependsOnMethods="searchDownloadSprint")
	public static void details() throws Exception {
		test.log(LogStatus.INFO, "Displaying given number of sprints");
		Details.displayItem(driver);
		test.log(LogStatus.PASS, "Display given no. of sprints successfully");
		test.log(LogStatus.INFO, "Entering page number");
		Details.pageNumber(driver);
		test.log(LogStatus.PASS, "Page no. entered successfully");
		test.log(LogStatus.INFO, "To go to next page");
		Details.buttonNext(driver);
		test.log(LogStatus.PASS, "Displayed sprints of next page successfully");
		test.log(LogStatus.INFO, "To go to last page");
		Details.buttonLast(driver);
		test.log(LogStatus.PASS, "Displayed sprints of last page successfully");
		test.log(LogStatus.INFO, "To refresh the page");
		Details.buttonRefresh(driver);
		test.log(LogStatus.PASS, "Refreshed the page successfully");
		}
	
	@Test(dependsOnMethods="details")
	public static void filter() throws Exception {
		test.log(LogStatus.INFO, "Creating and applying new filter");
		FilterSort.createFilter(driver);
		test.log(LogStatus.PASS, "New filter created and applied successfully");
		test.log(LogStatus.INFO, "Clearing all filter");
		FilterSort.clearFilter(driver);
		test.log(LogStatus.PASS, "All filters cleared successfully");
		test.log(LogStatus.INFO, "Sorting the sprints");
		FilterSort.sorting(driver);
		test.log(LogStatus.PASS, "Sprints sorted successfully");
		}
	
	//To close the browser
	@Test(dependsOnMethods="filter")
	public void closeApplication() {
	test.log(LogStatus.INFO, "Close the browser");
	driver.close();
	report.flush();
	test.log(LogStatus.PASS, "Browser closed successfully");
	}
}
